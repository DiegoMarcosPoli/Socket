﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Net.Sockets;
using System.Net;
using System.Windows.Threading;


namespace AppSocket
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Socket socket = null;
        DispatcherTimer dtimer;
        

        public MainWindow()
        {
            //AddressFamily --> enumerativo InterNetwork IPv4 
            //SocketType--> enumerativo Dgram utilizza datagrammi co protocollo udp
            InitializeComponent();
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, ProtocolType.Udp);
            //Identifico il Mittente
            IPAddress local_address = IPAddress.Any;
            //Creo l'inidirizzo IP del Mittente
            IPEndPoint local_Endpoint = new IPEndPoint(local_address.MapToIPv4(),34500);//socket necessita di due endpoint il primo è questo del mittente
            //porta utilizzata per lo scambio  messaggi 33500 per far comunicare più PC senza interruzione da parte dei firewall
            
            socket.Bind(local_Endpoint);//collego il socket all'endpoint,identifico per la socket il mittente

            dtimer = new DispatcherTimer();//inizializzo il dispatcher 
            dtimer.Tick += new EventHandler(aggiornamento_dTimer);//imposto l'evento che/metodo che il dispatcher eseguirà ogni volta che il timer finirà
            dtimer.Interval = new TimeSpan(0, 0, 0, 0, 250);//imposto l'intervallo di tempo del timer 
            dtimer.Start();//lo faccio partire
        }

        private void btnInvia_Click(object sender, RoutedEventArgs e)
        {
            //prendo l'ip del destinatario
            IPAddress remote_address = IPAddress.Parse(txtIp.Text);
            IPEndPoint remoteEndpoint = new IPEndPoint(remote_address, int.Parse(txtPorta.Text));//creazione endpoint destinatario Il secondo necessario
            byte[] messaggio = Encoding.UTF8.GetBytes(txtMessaggio.Text);//prendo il messaggio da inviare
           
            
            socket.SendTo(messaggio, remoteEndpoint);//invio il messaggio con il testo e il destinatario

        }

        private void aggiornamento_dTimer(object sender, EventArgs e)
        {
            //memorizzo il numero di bit ricevuti
            int bytes;

            if ((bytes = socket.Available) > 0)
            {
                
                byte[] buffer = new byte[bytes];//Ricevo i caratteri 
                
                EndPoint remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);//creo il remote endpoint con un IP di default(non so ancora chi è)
                bytes = socket.ReceiveFrom(buffer, ref remoteEndPoint);//passo il remote endpoint in ref così che al posto dell'IP di default vi inserisca quello del mittente(identifico il mittente)
                string from = txtContatto.Text + "  ";
                from += ((IPEndPoint)remoteEndPoint).Address.ToString();
                string messaggio = Encoding.UTF8.GetString(buffer, 0, bytes);//rendo il messaggio ricevuto sotto forma di byte una stringa

                lstMEssaggi.Items.Add(from + ": " + messaggio);
            }
        }
    }
}
